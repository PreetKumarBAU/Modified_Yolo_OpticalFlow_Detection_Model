"""
Creates a Pytorch dataset to load the Pascal VOC & MS COCO datasets
"""

import config
import numpy as np
import os
import pandas as pd
import torch

from PIL import Image, ImageFile
from torch.utils.data import Dataset, DataLoader
from utils import (
    cells_to_bboxes,
    iou_width_height as iou,
    non_max_suppression as nms,
    plot_image
)

ImageFile.LOAD_TRUNCATED_IMAGES = True


def inbetween(minv, val, maxv):
    return float(min(maxv, max(minv, val))) 

class YOLODataset(Dataset):
    def __init__(
        self,
        csv_file,
        img_dir,
        label_dir,
        anchors,
        image_size=416,
        S=[13, 26, 52],
        C=1,
        transform=None,
    ):
        self.annotations = pd.read_csv(csv_file)   ## It contains the "frameName" and "label txt file name"
        self.img_dir = img_dir
        self.label_dir = label_dir               ## It contains .txt files for each frame, having 
        self.image_size = image_size
        self.transform = transform
        self.S = S
        self.anchors = torch.tensor(anchors[0] + anchors[1] + anchors[2])  # for all 3 scales
        self.num_anchors = self.anchors.shape[0]
        self.num_anchors_per_scale = self.num_anchors // 3
        self.C = C
        self.ignore_iou_thresh = 0.5

    def __len__(self):
        return len(self.annotations)


    def target_according_to_different_scales(self, bboxes):
        # Below assumes 3 scale predictions (as paper) and same num of anchors per scale
        targets = [torch.zeros((self.num_anchors // 3, S, S, 6)) for S in self.S]
        for box in bboxes:
            iou_anchors = iou(torch.tensor(box[2:4]), self.anchors)
            anchor_indices = iou_anchors.argsort(descending=True, dim=0)
            x, y, width, height, class_label = box
            has_anchor = [False] * 3  # each scale should have one anchor
            for anchor_idx in anchor_indices:
                scale_idx = anchor_idx // self.num_anchors_per_scale
                anchor_on_scale = anchor_idx % self.num_anchors_per_scale
                S = self.S[scale_idx]
                i, j = int(S * y), int(S * x)  # which cell
                anchor_taken = targets[scale_idx][anchor_on_scale, i, j, 0]
                if not anchor_taken and not has_anchor[scale_idx]:
                    targets[scale_idx][anchor_on_scale, i, j, 0] = 1
                    minv = 0.0
                    maxv = 1.0
                    x_cell, y_cell = inbetween(minv, (S * x - j), maxv) ,inbetween(minv, (S * y - i), maxv)    # both between [0,1]
                    
                    width_cell, height_cell = (
                        width * S,
                        height * S,
                    )  # can be greater than 1 since it's relative to cell
                    box_coordinates = torch.tensor(
                        [x_cell, y_cell, width_cell, height_cell]
                    )
                    targets[scale_idx][anchor_on_scale, i, j, 1:5] = box_coordinates
                    targets[scale_idx][anchor_on_scale, i, j, 5] = int(class_label)
                    has_anchor[scale_idx] = True

                elif not anchor_taken and iou_anchors[anchor_idx] > self.ignore_iou_thresh:
                    targets[scale_idx][anchor_on_scale, i, j, 0] = -1  # ignore prediction
        return targets


    def __getitem__(self, index):
        
        try:
            label_path = os.path.join(self.label_dir, self.annotations.iloc[index, 1])
            bboxes = np.roll(np.loadtxt(fname=label_path, delimiter=" ", ndmin=2), 4, axis=1).tolist()
            img_path = os.path.join(self.img_dir , self.annotations.iloc[index, 0])
            image = np.array(Image.open(img_path).convert("RGB"))
            
            ## For Image2 and Label2 from "index + 1 "
            img_path2 = os.path.join(self.img_dir , self.annotations.iloc[index+1 , 0])
            label_path2 = os.path.join(self.label_dir, self.annotations.iloc[index+1, 1])
            bboxes2 = np.roll(np.loadtxt(fname=label_path2, delimiter=" ", ndmin=2), 4, axis=1).tolist()
            image2 = np.array(Image.open(img_path2).convert("RGB"))


            if self.transform:
                
                augmentations = self.transform(image=image,  image1=image2,  bboxes1= bboxes2 , bboxes = bboxes)
                image = augmentations["image"]
                bboxes = augmentations["bboxes"]
                image2 = augmentations["image1"]
                bboxes2 = augmentations["bboxes1"]
                

            targets =  self.target_according_to_different_scales( bboxes)
            targets2 =  self.target_according_to_different_scales( bboxes2)
            

            return image, tuple(targets) ,  label_path , image2 , tuple(targets2) , label_path2

        except:
            label_path = os.path.join(self.label_dir, self.annotations.iloc[index, 1])
            bboxes = np.roll(np.loadtxt(fname=label_path, delimiter=" ", ndmin=2), 4, axis=1).tolist()
            img_path = os.path.join(self.img_dir , self.annotations.iloc[index, 0])
            image = np.array(Image.open(img_path).convert("RGB"))
            


            if self.transform:
                
                augmentations = self.transform(image=image,  image1=image,  bboxes1= bboxes , bboxes = bboxes)
                image = augmentations["image"]
                bboxes = augmentations["bboxes"]
                image2 = augmentations["image1"]
                bboxes2 = augmentations["bboxes1"]
                

            targets =  self.target_according_to_different_scales( bboxes)
            targets2 =  self.target_according_to_different_scales( bboxes2)
            

            return image, tuple(targets) ,  label_path , image2 , tuple(targets2) , label_path
    
        
            


def test():
    anchors = config.ANCHORS

    transform = config.train_transforms

    dataset = YOLODataset(
        r"C:\Users\azure.lavdierada\yolov5\DA\train.csv",
        r"C:\Users\azure.lavdierada\yolov5\DA",
         r"C:\Users\azure.lavdierada\yolov5\DA",
        S=[13, 26, 52],
        anchors=anchors,
        transform=transform,
    )
    S = [13, 26, 52]
    scaled_anchors = torch.tensor(anchors) / (
        1 / torch.tensor(S).unsqueeze(1).unsqueeze(1).repeat(1, 3, 2)
    )
    loader = DataLoader(dataset=dataset, batch_size=1, shuffle=False)
    for x, y, l , x1, y1, l1 in loader:
        print(x[0].shape, y[0].shape, l)
        print(x1[0].shape, y1[0].shape, l1)
        
        boxes = []

        for i in range(y[0].shape[1]):
            anchor = scaled_anchors[i]
            print(anchor.shape)
            print(y[i].shape)
            boxes += cells_to_bboxes(
                y[i], is_preds=False, S=y[i].shape[2], anchors=anchor
            )[0]
        boxes = nms(boxes, iou_threshold=1, threshold=0.7, box_format="midpoint")
        print(boxes)
        plot_image(x[0].permute(1, 2, 0).to("cpu"), boxes)


### For the Second Image
        boxes = []

        for i in range(y1[0].shape[1]):
            anchor = scaled_anchors[i]
            print(anchor.shape)
            print(y1[i].shape)
            boxes += cells_to_bboxes(
                y1[i], is_preds=False, S=y1[i].shape[2], anchors=anchor
            )[0]
        boxes = nms(boxes, iou_threshold=1, threshold=0.7, box_format="midpoint")
        print(boxes)
        plot_image(x1[0].permute(1, 2, 0).to("cpu"), boxes)
        break
        

'''
if __name__ == "__main__":
    test()
'''